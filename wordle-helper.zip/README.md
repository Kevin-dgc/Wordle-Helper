#This is my Wordle Helper Extions for firefox!

to use it simply click on the extension and it will show you the words which are suggested based on the filled in wordle page




* commands to compile
`zip -r wordle-helper.zip . -x '*.git*' -x '*.DS_Store'`